
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/christian/Projects/JacknJunk/src/entity.c" "CMakeFiles/jacknjunk.dir/src/entity.c.o" "gcc" "CMakeFiles/jacknjunk.dir/src/entity.c.o.d"
  "/home/christian/Projects/JacknJunk/src/game.c" "CMakeFiles/jacknjunk.dir/src/game.c.o" "gcc" "CMakeFiles/jacknjunk.dir/src/game.c.o.d"
  "/home/christian/Projects/JacknJunk/src/main.c" "CMakeFiles/jacknjunk.dir/src/main.c.o" "gcc" "CMakeFiles/jacknjunk.dir/src/main.c.o.d"
  "/home/christian/Projects/JacknJunk/src/map.c" "CMakeFiles/jacknjunk.dir/src/map.c.o" "gcc" "CMakeFiles/jacknjunk.dir/src/map.c.o.d"
  "/home/christian/Projects/JacknJunk/src/scene.c" "CMakeFiles/jacknjunk.dir/src/scene.c.o" "gcc" "CMakeFiles/jacknjunk.dir/src/scene.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
