# Empty compiler generated dependencies file for jacknjunk.
# This may be replaced when dependencies are built.
