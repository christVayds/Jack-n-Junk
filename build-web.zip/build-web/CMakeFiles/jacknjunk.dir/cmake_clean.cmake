file(REMOVE_RECURSE
  "CMakeFiles/jacknjunk.dir/src/entity.c.o"
  "CMakeFiles/jacknjunk.dir/src/entity.c.o.d"
  "CMakeFiles/jacknjunk.dir/src/game.c.o"
  "CMakeFiles/jacknjunk.dir/src/game.c.o.d"
  "CMakeFiles/jacknjunk.dir/src/main.c.o"
  "CMakeFiles/jacknjunk.dir/src/main.c.o.d"
  "CMakeFiles/jacknjunk.dir/src/map.c.o"
  "CMakeFiles/jacknjunk.dir/src/map.c.o.d"
  "CMakeFiles/jacknjunk.dir/src/scene.c.o"
  "CMakeFiles/jacknjunk.dir/src/scene.c.o.d"
  "jacknjunk.html"
  "jacknjunk.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/jacknjunk.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
